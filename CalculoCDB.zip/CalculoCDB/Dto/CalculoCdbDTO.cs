﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CalculoCDB.Dto
{
    public class CalculoCdbDTO
    {
        public CalculoCdbDTO()
        {

        }
        public double ValorBruto { get; set; }
        public double ValorLiquido { get; set; }
    }
}