﻿using CalculoCDB.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CalculoCDB.Controllers
{
    public class CaculoCdbController : ApiController
    {
        public CalculoCdbDTO Get(double Valor, int Prazo)
        {
            double valorBruto = Valor;
            double valorLiquido;            
            double valorTB = 1.08;
            double valorCDI = 0.009;
            double taxaIR;
            double valorTaxado;

            List<string> errors = new List<string>();
            if (Valor<=0)
            {                
                errors.Add("O valor inicial deve ser maior que zero.");             
            }
            if (Prazo <=1)
            {
                errors.Add("O prazo deve ser maior que 1 mês.");
            }

            if(errors.Count > 0)
            {
                var responseMessage = new HttpResponseMessage(HttpStatusCode.BadRequest);                
                responseMessage.Content = new StringContent(string.Join(System.Environment.NewLine, errors));
                throw new HttpResponseException(responseMessage);
            }
            

            //calcula o valor bruto
            for (int i = 0; i < Prazo; i++)
                valorBruto = valorBruto * (1 + (valorTB * valorCDI));

            //calculando a taxa do IR 
            if (Prazo <= 6)
                taxaIR = 0.225;
            else if(Prazo > 6 && Prazo <= 12)
                taxaIR = 0.22;
            else if (Prazo > 12 && Prazo <= 24)
                taxaIR = 0.175;
            else 
                taxaIR = 0.15;

            //apurando o lucro 
            valorTaxado = valorBruto - Valor;

            //desconta o IR em cima do lucro e calcula o valor liquido
            valorLiquido = Valor + (valorTaxado - (valorTaxado * taxaIR));

            return new CalculoCdbDTO(){ ValorBruto = Math.Round(valorBruto,2,MidpointRounding.ToEven), ValorLiquido = Math.Round(valorLiquido,2,MidpointRounding.ToEven) };            
        }

    }
}
